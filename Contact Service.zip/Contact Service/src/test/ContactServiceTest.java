package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import contactService.ContactService;

public class ContactServiceTest {
	
	@Test
	void testAddContact() {
		ContactService.addContact("James", "Paul", 1234567890L, "House Ave, Texas");	//add three to the list
		ContactService.addContact("Sam", "Chillders", 9876543210L, "Tree Ave, Brazil");		
		ContactService.addContact("Tony", "Gates", 5551113333L, "Square Box, Detroit");		
		
		assertTrue(ContactService.contacts.get(0).getFirstName().equals("James"));//check entry 1
		assertTrue(ContactService.contacts.get(0).getLastName().equals("Paul"));
		assertTrue(String.valueOf(ContactService.contacts.get(0).getPhone()).equals("1234567890"));
		assertTrue(ContactService.contacts.get(0).getAddress().equals("House Ave, Texas"));
		
		assertTrue(ContactService.contacts.get(1).getFirstName().equals("Sam"));//check entry 2
		assertTrue(ContactService.contacts.get(1).getLastName().equals("Chillders"));
		assertTrue(String.valueOf(ContactService.contacts.get(1).getPhone()).equals("9876543210"));
		assertTrue(ContactService.contacts.get(1).getAddress().equals("Tree Ave, Brazil"));
		
		assertTrue(ContactService.contacts.get(2).getFirstName().equals("Tony"));//check entry 3
		assertTrue(ContactService.contacts.get(2).getLastName().equals("Gates"));
		assertTrue(String.valueOf(ContactService.contacts.get(2).getPhone()).equals("5551113333"));
		assertTrue(ContactService.contacts.get(2).getAddress().equals("Square Box, Detroit"));

	}
	
	@Test
	void testDeleteContact() {		
		ContactService.addContact("James", "Paul", 1234567890L, "House Ave, Texas");	//add three to the list
		ContactService.deleteContact(0);//deletes James
		
		assertTrue(ContactService.contacts.size()==0);//size is empty
	}
	
	@Test
	void testUpdateContact() {
		
		ContactService.addContact("Sam", "Chillders", 9876543210L, "Tree Ave, Brazil");	//add a contact	
		ContactService.updateContact(1, "Samantha", "Roberts", 9876543210L,"Hillcrest Ln, Computer");//updates contact at spot 1 in the list 
		
		assertTrue(ContactService.contacts.get(0).getFirstName().equals("Samantha"));//check entry 0
		assertTrue(ContactService.contacts.get(0).getLastName().equals("Roberts"));
		assertTrue(String.valueOf(ContactService.contacts.get(0).getPhone()).equals("9876543210"));
		assertTrue(ContactService.contacts.get(0).getAddress().equals("Hillcrest Ln, Computer"));
		
		ContactService.deleteContact(1);//deletes samantha
	}
	
}
