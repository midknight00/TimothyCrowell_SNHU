package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactService.Contact;

public class ContactTest {


	long id = 0;//this is done by the service class
	
	@Test
	void testContact() {
		Contact contact = new Contact(id, "James", "Paul", 1234567890L, "House Ave, Texas");
		id++;//this is done by the service and counts up
		assertTrue(contact.getFirstName().equals("James"));
		assertTrue(contact.getLastName().equals("Paul"));
		assertTrue(String.valueOf(contact.getPhone()).equals("1234567890"));		
		assertTrue(contact.getAddress().equals("House Ave, Texas"));	
	}
	
	@Test
	void testIDTooLong() {//junit test for ID length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(99999999999L, "James", "Paul", 1234567890L, "House Ave, Texas");
		});
	}
	
	@Test
	void testFirstNameTooLong() {//junit test for First Name length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(id, "James of America", "Paul", 1234567890L, "House Ave, Texas");
		});
	}
	
	@Test
	void testLastNameTooLong() {//junit test for Last Name length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(id, "James", "Paul The Great One", 1234567890L, "House Ave, Texas");
		});
	}
	
	@Test
	void testPhoneTooLong() {//junit test for Phone length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(id, "James", "Paul", 12345678901L, "House Ave, Texas");
		});
	}
	
	@Test
	void testAddressTooLong() {//junit test for Address length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(id, "James", "Paul", 1234567890L, "House Ave, Texas the State of america");
		});
	}

}
