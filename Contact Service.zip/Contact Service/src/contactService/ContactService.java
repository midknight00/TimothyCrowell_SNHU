package contactService;
import java.util.ArrayList; // import the ArrayList class

public class ContactService {
	
	public static ArrayList<Contact> contacts = new ArrayList<Contact>();
	static int id = 0;
	
	public static void addContact(String firstName, String lastName, long phone, String address) {
		
		Contact newContact = new Contact(id, firstName, lastName, phone, address);//creates and fills new contact, creating a new id
		
		contacts.add(newContact);//adds new contact to the list
		id++;//Increment id
	}
	
	public static void deleteContact(int id) {
		for(int i = 0; i < contacts.size(); i++) {
			Contact contact = contacts.get(i);//stores contact at i index
			if (contact.getId()==id) {//checks for match
				contacts.remove(i);//deletes match
			}
		}
	}
	
	public static void updateContact(int id, String firstName, String lastName, long phone, String address) {
		for(int i = 0; i < contacts.size(); i++) {
			Contact contact = contacts.get(i);//stores contact at i index
			if (contact.getId()==id) {//checks for match
				contact.setFirstName(firstName);//sets new data
				contact.setLastName(lastName);
				contact.setPhone(phone);
				contact.setAddress(address);
				
				contacts.set(i, contact);//updates contact
			}
		}
	}
}
