package contactService;

public class Contact {
	
	long id = 0;
	String firstName = "No Data";
	String lastName = "No Data";
	long phone = 5555555555L;
	String address = "No Data";
	
	//constructor
	public Contact(long id, String firstName, String lastName, long phone, String address) {//Unique id creator
		if (String.valueOf(id).length() > 10 || firstName.length() > 10 || firstName == null || lastName.length() > 10 || lastName == null || 
				String.valueOf(phone).length() > 10 || String.valueOf(phone) == null || address.length() > 30 || address == null) {
			throw new IllegalArgumentException("Inavalid input");
		}
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	//getters
	long getId() {
		return id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public long getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	//setters	
	void setFirstName(String firstName) {
		if (firstName.length() > 10 || firstName == null) {//assign value if less than 11 characters and not null.
			throw new IllegalArgumentException("Inavalid input");//otherwise throw exception
		}
		this.firstName = firstName;
	}
	
	void setLastName(String lastName) {		
		if (lastName.length() > 10 || lastName == null) {//assign value if less than 11 characters and not null.
			throw new IllegalArgumentException("Inavalid input");//otherwise throw exception
		}
		this.lastName = lastName;
	}
	
	void setPhone(long phone) {
		if (String.valueOf(phone).length() != 10 || String.valueOf(phone) == null) {//assign value if 10 characters.
			throw new IllegalArgumentException("Inavalid input");//otherwise throw exception
		}
		this.phone = phone;
	}
	
	void setAddress(String address) {
		if (address.length() > 30 || address == null) {//assign value if more than 30 characters and not null.
			throw new IllegalArgumentException("Inavalid input");//otherwise throw exception
		}
		this.address = address;
	}
}
