package com.example.m2aevents;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class credentialsDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "credentials.db";
    private static final int VERSION = 1;

    private static credentialsDB mCredDB;

    public static credentialsDB getInstance(Context context) {//for storing data after pause
        if (mCredDB == null) {
            mCredDB = new credentialsDB(context);
        }
        return mCredDB;
    }

    public credentialsDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {//sets data for table
        private static final String TABLE = "Log ins";
        private static final String COL_ID = "_ID";
        private static final String COL_USER = "Username";
        private static final String COL_PASS = "Password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//table for log ins
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USER + " text, " +
                LoginTable.COL_PASS + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    public void addCredentials(String user, String pass) {//add credentials to db
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USER, user);//adds credentials user and pass
        values.put(LoginTable.COL_PASS, pass);

        long logInId = db.insert(LoginTable.TABLE, null, values);
    }

    public boolean getCredentials(String user, String pass){//checks db for credentials
        SQLiteDatabase db = getWritableDatabase();
        //query for username
        Cursor cursor = db.rawQuery("select * from " + LoginTable.TABLE + " where username = ?", new String[] {user});
        if(cursor.moveToFirst()){
            if(pass == cursor.getString(1)){//match to password
                return true;
            }
        }
        return false;
    }
}
