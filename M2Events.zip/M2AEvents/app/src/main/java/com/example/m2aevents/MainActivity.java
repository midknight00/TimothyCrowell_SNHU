package com.example.m2aevents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private credentialsDB mCredDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loggin);
        getActionBar().setTitle("Log In");//for events view
        getSupportActionBar().setTitle("Log In View");
    }

    public void logIn(View view) {//if log in pressed
        if(findViewById(R.id.userName) != null && findViewById(R.id.password) != null){//check for null
            mCredDb = credentialsDB.getInstance(getApplicationContext());
            if(mCredDb.getCredentials(findViewById(R.id.userName).toString(),findViewById(R.id.password).toString())) {//pass user and pass to db
                Intent intent = new Intent(this, eventActivity.class);//starts event viewer
                startActivity(intent);
            } else {
                //TODO: invalid log in handling
            }
        }
    }

    public void addLogIn(View view) {
        if(findViewById(R.id.userName) != null && findViewById(R.id.password) != null){//check for null
            mCredDb = credentialsDB.getInstance(getApplicationContext());
            String user = findViewById(R.id.userName).toString(); String pass = findViewById(R.id.password).toString();//convert
            mCredDb.addCredentials(user, pass);//adds credentials to db
            Intent intent = new Intent(this, eventActivity.class);//starts event viewer
            startActivity(intent);
        }
    }
}

