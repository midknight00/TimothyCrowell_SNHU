package com.example.m2aevents;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.util.List;


public class eventActivity extends AppCompatActivity {
    private eventDb mEventDb;
    private TextView event;
    private TextView date;
    private TextView details;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getActionBar().setTitle("Events");//for events view
        getSupportActionBar().setTitle("Events View");
        loadDb();//loads db on create
    }
    public void loadDb(){//fills events with database
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(mEventDb != null){//if db not empty
            eventDb.getEvents(0);
            int id = 0;
            List<String> vals = eventDb.vals;
            while (vals != null){
                switch (id) {
                    case 0:
                        event = findViewById(R.id.events1);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText1);
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details1);
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    case 1:
                        event = findViewById(R.id.events2);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText2);//date
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details2);//details
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    case 2:
                        event = findViewById(R.id.events3);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText3);
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details3);
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    case 3:
                        event = findViewById(R.id.events4);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText4);
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details4);
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    case 4:
                        event = findViewById(R.id.events5);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText5);
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details5);
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    case 5:
                        event = findViewById(R.id.events6);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText6);
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details6);
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    case 6:
                        event = findViewById(R.id.events7);//set textview
                        event.setText(vals.get(0));//set text to event name
                        date = findViewById(R.id.dateText7);
                        date.setText(vals.get(1));
                        details = findViewById(R.id.details7);
                        details.setText(vals.get(2));
                        id++;
                        eventDb.getEvents(id);
                        vals = eventDb.vals;
                        break;
                    default:
                        vals = null;
                        break;
                }
            }
        }
    }

    public void startPrefs(MenuItem item) {//for settings on click
        Intent intent = new Intent(this, preferences.class);//sets event viewer
        startActivity(intent);//starts event
    }

    public void deleteEvent1(View view) {//delete event
        String eventName = findViewById(R.id.events1).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void deleteEvent2(View view) {//delete event
        String eventName = findViewById(R.id.events2).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void deleteEvent3(View view) {//delete event
        String eventName = findViewById(R.id.events3).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void deleteEvent4(View view) {//delete event
        String eventName = findViewById(R.id.events4).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void deleteEvent5(View view) {//delete event
        String eventName = findViewById(R.id.events5).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void deleteEvent6(View view) {//delete event
        String eventName = findViewById(R.id.events6).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void deleteEvent7(View view) {//delete event
        String eventName = findViewById(R.id.events7).toString();//finds event name
        mEventDb = eventDb.getInstance(getApplicationContext());
        if(eventName != null){
            mEventDb.deleteEvent(eventName);//remove event by name
        }
    }

    public void addAnEvent(View view) {
        new eventDialog();//creates new event with a pop up
    }

    public void editEvents1(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 0;//not sure how to call this before the dialog on create
    }

    public void editEvents2(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 1;//not sure how to call this before the dialog on create
    }

    public void editEvents3(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 2;//not sure how to call this before the dialog on create
    }

    public void editEvents4(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 3;//not sure how to call this before the dialog on create
    }

    public void editEvents5(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 4;//not sure how to call this before the dialog on create
    }

    public void editEvents6(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 5;//not sure how to call this before the dialog on create
    }

    public void editEvents7(View view) {
        mEventDb = eventDb.getInstance(getApplicationContext());
        eventUpdateDialog update = new eventUpdateDialog();
        update.id = 6;//not sure how to call this before the dialog on create
    }
}
class eventDialog extends DialogFragment {
    private eventDb mEventDb;
    private View eventText;
    private View eventDetails;
    private View eventDate;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.newEvent)
                .setPositiveButton(R.string.finished, (dialog, id) -> {//user clicks ok
                    String eventName = eventText.toString();
                    String details = eventDetails.toString();
                    String date = eventDate.toString();
                    if(eventName != null && details != null && date != null){
                        mEventDb = eventDb.getInstance(getApplicationContext());
                        mEventDb.addEvent(eventName,details,date);//adds event to db
                    }
                })
                .setNegativeButton(R.string.cancel, (dialog, id) -> {
                    // User cancelled the dialog
                }).setView(eventText).setView(eventDetails).setView(eventDate);//boxes for events and details and date
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
class eventUpdateDialog extends DialogFragment {
    int id;
    private eventDb mEventDb;
    private View eventText;
    private View eventDetails;
    private View eventDate;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.newEvent)
                .setPositiveButton(R.string.finished, (dialog, id) -> {//user clicks ok
                    String eventName = eventText.toString();
                    String details = eventDetails.toString();
                    String date = eventDate.toString();
                    if(eventName != null && details != null && date != null){
                        mEventDb = eventDb.getInstance(getApplicationContext());
                        mEventDb.updateEvent(id,eventName,details,date);//adds event to db
                    }
                })
                .setNegativeButton(R.string.cancel, (dialog, id) -> {
                    // User cancelled the dialog
                }).setView(eventText).setView(eventDetails).setView(eventDate);//boxes for events and details and date
        // Create the AlertDialog object and return it
        return builder.create();
    }
}