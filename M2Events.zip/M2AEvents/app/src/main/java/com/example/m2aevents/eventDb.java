package com.example.m2aevents;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class eventDb extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event.db";
    private static final int VERSION = 1;

    private static eventDb mCredDB;
    public static List<String> vals = new ArrayList<String>();;

    public static eventDb getInstance(Context context) {//for storing data after pause
        if (mCredDB == null) {
            mCredDB = new eventDb(context);
        }
        return mCredDB;
    }

    public eventDb(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class EventTable {//sets data for table
        private static final String TABLE = "events";
        private static final String COL_ID = "_ID";
        private static final String COL_NAME = "eventName";
        private static final String COL_DATE = "eventDate";
        private static final String COL_DETAILS = "eventDetails";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//table for events
        db.execSQL("create table " + EventTable.TABLE + " (" +
                EventTable.COL_ID + " integer primary key autoincrement, " +
                EventTable.COL_NAME + ", text, " +
                EventTable.COL_DATE + ", text, " +
                EventTable.COL_DETAILS + ", text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + EventTable.TABLE);
        onCreate(db);
    }

    public void addEvent(String name, String date, String details) {//add events to db
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(EventTable.COL_NAME, name);//adds event info
        values.put(EventTable.COL_DATE, date);
        values.put(EventTable.COL_DATE, details);

        long logInId = db.insert(EventTable.TABLE, null, values);
    }

    public static void getEvents(int id){//supplies db with recourses
        SQLiteDatabase db = getWritableDatabase();
        //query for username
        Cursor cursor = db.rawQuery("select * from " + EventTable.TABLE + " where ID = ?", new String[] {String.valueOf(id)});
        if(cursor.moveToFirst()){
            vals.add(cursor.getString(1));//event name
            vals.add(cursor.getString(2));//event date
            vals.add(cursor.getString(3));//details
            //return vals;
        } else {
            vals = null;
        }
        //return null;
    }

    public void updateEvent(int id, String name, String date, String details) {//add events to db
        SQLiteDatabase db = getWritableDatabase();

        ContentValues newValues = new ContentValues();
        newValues.put(EventTable.COL_NAME, name);//adds event info
        newValues.put(EventTable.COL_DATE, date);
        newValues.put(EventTable.COL_DATE, details);

        Cursor cursor = db.rawQuery("select * from " + EventTable.TABLE + " where ID = ?", new String[] {String.valueOf(id)});//finds event by id
        if(cursor.moveToFirst()){
            db.update(EventTable.TABLE, newValues, "ID=?", new String[]{String.valueOf(id)});//updates with new values
        } else {
            //Toast.makeText(getApplicationContext(),
            //        "Update failed, please try again.", Toast.LENGTH_LONG).show();
            return;
        }
    }

    public void deleteEvent(String name) {//delete events from db
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from " + EventTable.TABLE + " where eventName = ?", new String[] {name});//find by name
        if(cursor.moveToFirst()){
            db.delete(EventTable.TABLE, "name=?", new String[]{name});//deletes from db
        }
    }
}
