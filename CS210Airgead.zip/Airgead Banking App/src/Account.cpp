#include <iostream>
#include <iomanip>
using namespace std;

#include "Account.h"

Account::Account(double startAmmount, double deposits,  double rate, int years) {//constructor
   this->iInvestment = startAmmount;
   this->mDeposit = deposits;
   this->iRate = rate;
   this->numYears = years;
}

void Account::PrintAccount() {//print
   double intrest;
   double total;
   double closingBalance;
   double yearlyIntrest;
   int i;//loop 1
   int j;//loop 2
   
   cout << "+--------------------------------------+"<< "\nYear\tYear end total\tIntrest earned"<<endl;//header
   for (i=0; i < this->numYears; i++){
       cout << i+1;
       yearlyIntrest = 0;
       for (j=0; j < 12; j++){
            total = this->mDeposit + this->iInvestment;
            intrest = (this->iInvestment + this->mDeposit) * ((this->iRate/100)/12);
            this->iInvestment = intrest + total;
            yearlyIntrest += intrest;
       }
       cout << "         $" << setprecision(2) << fixed << iInvestment;
       cout << "          $" << yearlyIntrest << endl;//intrest made that year
   }  
   cout <<"+--------------------------------------+" << endl;
   cout << endl;
}