//Timothy Crowell
//SNHU C++, June 7, 2020
//project 2
#include <iostream>
#include <stdio.h>

using namespace std;
#include "Account.h"

int main()
{
    double monthly;
    double intrestRate;
    double initialTotal;
    int numYears;
    //Account withMonthly;
    //Account withoutMonthly;
    char c;
    
    cout << "      Welcome to Airgead"<< endl;//asks questions for input
    cout << "Enter initial account ammount: ";
    cin >> initialTotal;
    cout << "Enter monthly deposit: ";
    cin >> monthly;
    cout << "Enter annual intrest rate: ";
    cin >> intrestRate;
    cout << "Enter number of years: ";
    cin >> numYears;
    cout << "Press enter to continue...";
    cout << endl;
    c = getchar();//supposed to pause for input
    
    Account* withMonthly = new Account(initialTotal,monthly,intrestRate,numYears);//builds 2 objects, one with intrest and one wihtout
    Account* withoutMonthly = new Account(initialTotal,0.00,intrestRate,numYears);
    
    cout << "Balance and Account Info Without Deposit" << endl;
    withoutMonthly->PrintAccount();//prints both objects
    cout << "Balance and Account Info With Deposit" << endl;
    withMonthly->PrintAccount();
    
    return 0;
}
