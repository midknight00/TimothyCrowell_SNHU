#ifndef Account_H
#define Account_H

#include <string>
using namespace std;

class Account {
   public:
      Account(double startAmmount, double deposits,  double rate, int years);//main constructor
      
      void  PrintAccount();
      
   private:
      double iInvestment;
      double mDeposit;
      double iRate;
      int numYears;
      double total;
};
#endif