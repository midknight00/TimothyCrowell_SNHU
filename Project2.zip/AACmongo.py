{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "from pymongo import MongoClient\n",
    "from bson.objectid import ObjectId\n",
    "\n",
    "class AnimalShelter(object):\n",
    "    \"\"\" CRUD operations for Animal collection in MongoDB \"\"\"\n",
    "\n",
    "    def __init__(self):\n",
    "        # Initializing the MongoClient. This helps to \n",
    "        # access the MongoDB databases and collections. \n",
    "        self.client = MongoClient('mongodb://%s:%s@localhost:38681' % (aacUser, empire))\n",
    "        self.database = self.client['project']\n",
    "\n",
    "# created method to implement the C in CRUD.\n",
    "    def create(self, data):\n",
    "        if data is not None:\n",
    "            self.database.animals.insert(data)  # data should be dictionary  \n",
    "            myAnimal = { \"name\": \"Starfish\", \"color\": \"blue\" }#item to insert created\n",
    "            self.database.animals.inserOne(myAnimal)#item inserted into database\n",
    "            print(myAnimal)#prints created animal\n",
    "        else:\n",
    "            raise Exception(\"Nothing to save, because data parameter is empty\")\n",
    "\n",
    "# Created method to implement the R in CRUD.         \n",
    "    def read(self, data):\n",
    "        if data is not None:\n",
    "            self.database.animals.insert(data)  # data should be dictionary\n",
    "            x = animals.find({\"name\": \"Starfish\"})#item to find\n",
    "            print(x)#prints found item\n",
    "        else:\n",
    "            raise Exception(\"Nothing to save, because data parameter is empty\")\n",
    "            \n",
    "# created method for update            \n",
    "    def update(self, data):\n",
    "        if data is not None:\n",
    "            self.database.animals.insert(data)  # data should be dictionary\n",
    "            x = animals.find({\"name\": \"Starfish\"})#item to find\n",
    "            newVals = { \"$set\" : { \"name\" : \"Mr Whiskers\"}}#new value\n",
    "            animals.update_one(x,nawVals)#add to db\n",
    "            print(x)#prints found item\n",
    "        else:\n",
    "            raise Exception(\"Nothing to save, because data parameter is empty\")\n",
    "            \n",
    "# created method for delete            \n",
    "    def delete(self, data):\n",
    "        if data is not None:\n",
    "            self.database.animals.insert(data)  # data should be dictionary\n",
    "            x = animals.find({\"name\": \"Starfish\"})#item to find\n",
    "            animals.delte_one(x)#deletes item\n",
    "        else:\n",
    "            raise Exception(\"Nothing to save, because data parameter is empty\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.6.9"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
