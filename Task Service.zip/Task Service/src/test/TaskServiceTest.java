package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import taskService.TaskService;

public class TaskServiceTest {
	
	@Test
	void testAddTask() {
		TaskService.addTask("Shutdown", "Shutdown the system");	//add three to the list
		TaskService.addTask("Restart", "Restart the system");		
		TaskService.addTask("Sleep", "Apply system standby");		
		
		assertTrue(TaskService.taskList.get(0).getName().equals("Shutdown"));//check entry 1
		assertTrue(TaskService.taskList.get(0).getDescription().equals("Shutdown the system"));
		
		assertTrue(TaskService.taskList.get(1).getName().equals("Restart"));//check entry 2
		assertTrue(TaskService.taskList.get(1).getDescription().equals("Restart the system"));
		
		assertTrue(TaskService.taskList.get(2).getName().equals("Sleep"));//check entry 3
		assertTrue(TaskService.taskList.get(2).getDescription().equals("Apply system standby"));
		
		assertTrue(TaskService.taskList.get(0).getId() != TaskService.taskList.get(1).getId() || //unique id entry test
				TaskService.taskList.get(1).getId() != TaskService.taskList.get(0).getId() );//check entry 3

	}
	
	@Test
	void testDeleteTask() {
		
		TaskService.deleteTask(1);//deletes restart
		assertTrue(TaskService.taskList.size()==2);//add three take away 1 is 2
	}
	
	@Test
	void testUpdateTask() {	
		
		TaskService.updateTask(1, "Reboot", "Reboots the system");//updates task at spot 1 in the list 
		assertTrue(TaskService.taskList.get(1).getName().equals("Reboot"));//check entry 2
		assertTrue(TaskService.taskList.get(1).getDescription().equals("Reboots the system"));//check entry 2

	}
	
}
