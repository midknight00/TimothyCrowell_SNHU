package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskService.Task;

public class TaskTest {

	long id = 0;//this is done by the service class
	
	@Test
	void testTask() {
		Task task = new Task(id, "Shutdown", "Shutdown the system");
		id++;//this is done by the service and counts up
		assertTrue(task.getName().equals("Shutdown"));
		assertTrue(task.getDescription().equals("Shutdown the system"));		
	}
	
	@Test
	void testIDTooLong() {//junit test for ID length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(99999999999L, "Shutdown", "Shutdown the system");
		});
	}
	
	@Test
	void testNameTooLong() {//junit test for Name length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(id, "Thomas Jefferson", "United States President");
		});
	}
	
	@Test
	void testDescriptionTooLong() {//junit test for Description length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(id, "Thomas Jefferson", "Thomas Jefferson was an American statesman, "
					+ "diplomat, lawyer, architect, philosopher, and the third president of the United States from 1801 to 1809.");
		});
	}
}
