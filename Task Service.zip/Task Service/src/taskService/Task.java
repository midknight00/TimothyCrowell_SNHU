package taskService;

public class Task {
	long id = 0;
	String name;
	String description;
	
	//constructor
	public Task(long id, String name, String description) {//creates a task with a unique id 
		if (String.valueOf(id).length() > 10 || name.length() > 10 || name == null || description.length() > 20 || description == null) {
			throw new IllegalArgumentException("Inavalid input");
		}
		this.id = id;
		this.name = name;
		this.description = description;
	}
	
	//getters
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	//setters	
	void setName(String name) {
		if (name.length() > 10 || name == null) {//assign value if less than 11 characters and not null.
			throw new IllegalArgumentException("Inavalid input");//otherwise throw exception
		}
		this.name = name;
	}
	
	void setDescription(String description) {		
		if (description.length() > 20 || description == null) {//assign value if less than 21 characters and not null.
			throw new IllegalArgumentException("Inavalid input");//otherwise throw exception
		}
		this.description = description;
	}
	
}
