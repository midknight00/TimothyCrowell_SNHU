package taskService;
import java.util.ArrayList;

public class TaskService {

	public static ArrayList<Task> taskList = new ArrayList<Task>();//list of tasks
	private static int id = 0;//first id is 0 and goes up from there
	
	public static void addTask(String name, String description) {//much more streamlined than contact service
		Task newTask = new Task(id, name, description);//creates and fills new task with data and a new unique id
		
		taskList.add(newTask);//adds new task to task list
		id++;//Increment id to ensure uniqueness
	}
	
	public static void deleteTask(int id) {
		for(int i = 0; i < taskList.size(); i++) {
			Task task = taskList.get(i);//stores task at i index
			if (task.getId()==id) {//checks for match
				taskList.remove(i);//deletes match if found
			}
		}
	}
	
	public static void updateTask(int id, String name, String description) {//updates both
		for(int i = 0; i < taskList.size(); i++) {
			Task task = taskList.get(i);//stores task at i index
			if (task.getId()==id) {//checks for match
				
				if (name != null) {//checks for null
					task.setName(name);//sets new data
				}
				
				if (description != null) {//checks for null
					task.setDescription(description);
				}
				
				taskList.set(i, task);//updates task list
			}
		}
	}


}
