package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointmentService.Appointment;


public class AppointmentTest {


	long id = 0;//this is done by the service class
	
	@Test
	void appointmentTask() {
		Appointment appointment = new Appointment(id, LocalDate.of(2021, 9, 9), "Meeting with Grace");
		id++;//this is done by the service and counts up
		assertTrue(appointment.getDate().equals(LocalDate.of(2021, 9, 9)));
		assertTrue(appointment.getDescription().equals("Meeting with Grace"));		
	}
	
	@Test
	void appointmentIDTooLong() {//junit test for ID length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(99999999999L,LocalDate.of(2021, 9, 9), "Meeting with Grace");
		});
	}
	
	@Test
	void appointmentDateTooEarly() {//junit test for Name length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(id, LocalDate.of(2020, 9, 9), "Meeting with Grace");
		});
	}
	
	@Test
	void appointmentDescriptionTooLong() {//junit test for Description length
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(id, LocalDate.of(2021, 9, 9), "Meeting with Grace in the parkinglot of"
					+ "the grand central station terminal connecting branch");
		});
	}
}
