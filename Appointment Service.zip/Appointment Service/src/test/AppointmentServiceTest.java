package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import appointmentService.AppointmentService;


public class AppointmentServiceTest {
	
	@Test
	void testAddAppointment() {
		AppointmentService.addAppointment(LocalDate.of(2021, 8, 9), "Meeting with Grace");	//add three to the list
		AppointmentService.addAppointment(LocalDate.of(2021, 9, 9), "James' birthday party");	//add three to the list
		AppointmentService.addAppointment(LocalDate.of(2021, 10, 9), "volunteering at the food bank");	//add three to the list
		
		assertTrue(AppointmentService.appointmentList.get(0).getDate().equals(LocalDate.of(2021, 8, 9)));//check entry 1
		assertTrue(AppointmentService.appointmentList.get(0).getDescription().equals("Meeting with Grace"));
		
		assertTrue(AppointmentService.appointmentList.get(1).getDate().equals(LocalDate.of(2021, 9, 9)));//check entry 2
		assertTrue(AppointmentService.appointmentList.get(1).getDescription().equals("James' birthday party"));
		
		assertTrue(AppointmentService.appointmentList.get(2).getDate().equals(LocalDate.of(2021, 10, 9)));//check entry 2
		assertTrue(AppointmentService.appointmentList.get(2).getDescription().equals("volunteering at the food bank"));
		
		assertTrue(AppointmentService.appointmentList.get(0).getId() != AppointmentService.appointmentList.get(1).getId() || //unique id entry test
				AppointmentService.appointmentList.get(1).getId() != AppointmentService.appointmentList.get(2).getId() );//check entry 3

	}
	
	@Test
	void testDeleteAppointment() {
		
		AppointmentService.deleteAppointment(1);//deletes restart
		assertTrue(AppointmentService.appointmentList.size()==2);//add three take away 1 is 2
	}
	
}
