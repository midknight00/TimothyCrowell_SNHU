package appointmentService;

import java.time.LocalDate;

public class Appointment {

	long id = 0;
	LocalDate date;
	LocalDate currDate = LocalDate.now();//current date
	String description;
	
	//constructor
	public Appointment(long id, LocalDate date, String description) {//creates a task with a unique id 
		if (String.valueOf(id).length() > 10 || date.compareTo(currDate) < 0|| date == null || description.length() > 50 || description == null) {
			throw new IllegalArgumentException("Inavalid input");
		}
		this.id = id;
		this.date = date;
		this.description = description;
	}
	
	//getters
	public long getId() {
		return id;
	}
	
	public LocalDate getDate() {
		return date;
	}
	
	public String getDescription() {
		return description;
	}
}
