package appointmentService;

import java.util.ArrayList;
import java.time.LocalDate;


public class AppointmentService {

	public static ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();//list of appointments
	private static int id = 0;//first id is 0 and goes up from there
	
	public static void addAppointment(LocalDate date, String description) {
		Appointment  newAppointment = new Appointment (id, date, description);//creates and fills new appointment with data and a new unique id
		
		appointmentList.add(newAppointment);//adds new appointment to list
		id++;//Increment id to ensure uniqueness
	}
	
	public static void deleteAppointment(int id) {
		for(int i = 0; i < appointmentList.size(); i++) {
			Appointment appointment = appointmentList.get(i);//stores task at i index
			if (appointment.getId()==id) {//checks for match
				appointmentList.remove(i);//deletes match if found
			}
		}
	}

}
